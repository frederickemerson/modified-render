xoshiro128starstar.c

Reference implementation of the xoshiro128** pseudorandom number generator.
Downloaded from http://xoshiro.di.unimi.it/xoshiro128starstar.c on 2018-11-20.

splitmix64.c

Reference implementation of the SplitMix64 pseudorandom number generator.
Downloaded from http://xoshiro.di.unimi.it/splitmix64.c on 2018-11-20.
